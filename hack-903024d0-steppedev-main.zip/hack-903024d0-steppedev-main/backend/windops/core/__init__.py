"""Shared configuration and infrastructure."""
